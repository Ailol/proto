# Semantic overlay — after independent emission

The non-semantic runs remain the evidence layer. This file restores the original design question only after A, B, and C have emitted independently.

`measurement → contextual need → role assignment → render → feedback ↺⁻`

## A → `<dev>`

Highest occupancy, contrast, entropy, and sustained mean salience.

Use where the mark must remain present and legible in a compact working surface.

Constraint: repeated placement can make a dense interface feel heavier than its physical size suggests.

## B → `<div>` / hero

Highest local salience peak, chroma salience, and horizontal concentration.

Use for the deliberate visual moment: hero, reveal, signature, or premium surface.

Constraint: one focal instance carries better than repetition; duplication competes with the page.

## C → public

Lowest field energy, occupancy, contrast, edge density, and chroma, with by far the greatest temperature balance.

Use for public headers, documentation, institutional presentation, and surfaces where the work should speak before the mark.

Constraint: verify minimum rendered size because its restraint is also its failure surface.

## Deployment rule

`public_default=C`

`working_compact=A`

`intentional_focal_event=B`

The assignment is contextual, not essential: none of the three *is* its role. If size, background, or surrounding density changes materially, rerun the non-semantic measurement at the final rendered pixels.
