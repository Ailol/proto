from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
import re
from typing import Any, Iterable


NODE_TYPES = {
    "L.nt", "L.h", "L.p", "L.cb", "L.ni", "L.ns", "L.mb", "R", "Gp",
    "2m", "K", "Ph", "NR", "TF", "G", "T", "E", "V", "E.v", "E.lf",
    "E.gj", "Ch", "Ch.vg", "Ch.mec", "Ch.trp", "M.atp", "M.glc", "M.ros",
    "M.o2", "Mt", "M:*", "N.pyr", "N.da", "N.5ht", "N.gaba", "N.gran",
    "N.glia", "N.glia.mg", "N.glia.as", "N.ent", "N.eec", "N.icc", "B.gut",
    "B.bbb", "B.beh", "P.agg", "P.oligo",
}

REGIONS = {
    "PVN", "LC", "DRN", "VTA", "NAc", "AMY", "BLA", "CeA", "HPC", "PFC",
    "ACC", "INS", "SCN", "PIT", "PAG", "RVM", "EC", "SN", "LH", "BST", "POA",
    "DG", "thalamus", "NBM", "striatum", "GPi", "GPe", "STN", "pons", "SLD",
    "spinal", "ENS", "GUT", "VAG", "NTS", "DMV", "AP", "ARC", "ADR", "THYROID",
    "GONAD", "LIVER", "systemic", "plasma", "kidney", "cardiac", "behavior",
}

STATES = {"++", "+", "=", "~", "-", "--", "X", "*"}
DELTA_STATES = {"++", "+", "=", "~", "-", "--"}
NODE_PROPS = {
    "Gs", "Gi", "Gq", "G12", "Cl⁻", "Ca²⁺", "Na⁺", "K⁺", "RTK", "JAK-STAT",
    "heteromer", "up", "down", "des", "act", "block", "intern",
}
CASCADE_TAGS = {
    "GPCR.Gs", "GPCR.Gi", "GPCR.Gq", "GPCR.G12", "NUCLEAR", "RTK", "CYTOKINE",
    "IONOTROPIC", "VAGAL", "GUT_HORMONE", "ENZ", "RECYCLE", "TRANSPORT",
}
FATES = {"↺⁺", "↺⁻", "↺⁰", "→⊘", "→□", "→≋", "→Δm"}
RELATIONSHIPS = {"direct", "proxy", "ratio", "activity", "metabolite", "autonomic"}
INTEGRATION_MODES = {"thr", "rate", "burst", "tonic"}
PROTOCOL_PARAMS = {"exc", "inh", "mod", "fast", "slow", "tonic", "syn", "vol", "gap", "para"}
CONSTRUCT_ORDER = {
    "chain": 0,
    "integration": 1,
    "protocol": 2,
    "composite": 3,
    "dysregulation": 4,
    "observable": 5,
    "conditional": 6,
}
PROHIBITED = ("Δn:", "σ̃", "∫̃", "⊲̃", "⊗̃", "∮", "⊳")


@dataclass(frozen=True)
class Diagnostic:
    severity: str
    code: str
    message: str
    line: int
    column: int = 1

    def render(self, source_name: str = "<memory>") -> str:
        return f"{source_name}:{self.line}:{self.column}: {self.severity} {self.code}: {self.message}"


@dataclass(frozen=True)
class Node:
    type: str
    code: str
    region: str
    state: str | None = None
    props: tuple[str, ...] = ()

    @property
    def bare_key(self) -> str:
        return f"{self.code}@{self.region}"

    @property
    def typed_key(self) -> str:
        return f"{self.type}:{self.code}@{self.region}"


@dataclass
class Delta:
    code: str
    region: str
    sign: str
    exogenous: str | None
    line: int

    @property
    def bare_key(self) -> str:
        return f"{self.code}@{self.region}"


@dataclass
class Construct:
    kind: str
    line: int
    raw: str
    nodes: list[Node] = field(default_factory=list)
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class Pathway:
    name: str
    line: int
    refs: list[Node] = field(default_factory=list)
    constructs: list[Construct] = field(default_factory=list)


@dataclass
class Document:
    clinical_mode: bool = False
    domains: list[str] = field(default_factory=list)
    context: list[str] = field(default_factory=list)
    fates: list[str] = field(default_factory=list)
    open_ends: int | None = None
    deltas: list[Delta] = field(default_factory=list)
    pathways: list[Pathway] = field(default_factory=list)
    cross: list[Construct] = field(default_factory=list)

    def to_ir(self) -> dict[str, Any]:
        return {
            "format": "BioChain-BASE-IR",
            "version": 1,
            "profile": "clinical-structure" if self.clinical_mode else "base",
            "ingrainment": {
                "status": "provisional",
                "automatic": False,
                "doctor_review_required": True,
                "compiler_claims_clinical_truth": False,
            },
            "domains": self.domains,
            "context": self.context,
            "fates": self.fates,
            "open_ends": self.open_ends,
            "deltas": [asdict(item) | {"bare_key": item.bare_key} for item in self.deltas],
            "pathways": [
                {
                    "name": pathway.name,
                    "line": pathway.line,
                    "refs": [asdict(node) for node in pathway.refs],
                    "constructs": [
                        {
                            "kind": construct.kind,
                            "line": construct.line,
                            "raw": construct.raw,
                            "nodes": [asdict(node) for node in construct.nodes],
                            "data": construct.data,
                        }
                        for construct in pathway.constructs
                    ],
                }
                for pathway in self.pathways
            ],
            "cross": [
                {
                    "kind": construct.kind,
                    "line": construct.line,
                    "raw": construct.raw,
                    "nodes": [asdict(node) for node in construct.nodes],
                    "data": construct.data,
                }
                for construct in self.cross
            ],
        }


@dataclass
class CompilationResult:
    document: Document
    diagnostics: list[Diagnostic]

    @property
    def ok(self) -> bool:
        return not any(item.severity == "error" for item in self.diagnostics)

    def ir_json(self, *, pretty: bool = True) -> str:
        if not self.ok:
            raise ValueError("cannot emit IR from an invalid BioChain document")
        return json.dumps(
            self.document.to_ir(),
            ensure_ascii=False,
            indent=2 if pretty else None,
            separators=None if pretty else (",", ":"),
        ) + "\n"


class Compiler:
    def __init__(self, *, clinical: bool = False) -> None:
        self.clinical = clinical
        self.document = Document(clinical_mode=clinical)
        self.diagnostics: list[Diagnostic] = []
        self.current_pathway: Pathway | None = None
        self.in_cross = False
        self.seen_header = False
        self.seen_context = False
        self.seen_fates = False
        self.seen_open_ends = False
        self.seen_pathway = False
        self.known_typed: dict[str, int] = {}
        self.known_bare: dict[str, int] = {}

    def error(self, line: int, code: str, message: str, column: int = 1) -> None:
        self.diagnostics.append(Diagnostic("error", code, message, line, column))

    def warning(self, line: int, code: str, message: str, column: int = 1) -> None:
        self.diagnostics.append(Diagnostic("warning", code, message, line, column))

    def compile(self, source: str) -> CompilationResult:
        if not source:
            self.error(1, "BC001", "source is empty")
            return CompilationResult(self.document, self.diagnostics)

        lines = source.splitlines()
        for line_number, raw in enumerate(lines, 1):
            if not raw.strip():
                self.error(line_number, "BC002", "blank lines are forbidden")
                continue
            if raw != raw.lstrip():
                self.error(line_number, "BC003", "indentation is forbidden")
            line = raw.strip()
            for token in PROHIBITED:
                if token in line:
                    self.error(line_number, "BC004", f"operator {token!r} is outside BioChain-BASE")
            self._parse_line(line_number, line)

        self._finish(lines)
        self.diagnostics.sort(key=lambda item: (item.line, item.column, item.severity, item.code))
        return CompilationResult(self.document, self.diagnostics)

    def _parse_line(self, line_number: int, line: str) -> None:
        if line.startswith("@domain:"):
            self._parse_domain(line_number, line)
        elif line.startswith("#"):
            self._parse_context(line_number, line)
        elif line.startswith("::fates"):
            self._parse_fates(line_number, line)
        elif line.startswith("::open_ends"):
            self._parse_open_ends(line_number, line)
        elif line.startswith("Δ("):
            self._parse_delta(line_number, line)
        elif line.startswith("::pathway"):
            self._parse_pathway(line_number, line)
        elif line.startswith("::refs"):
            self._parse_refs(line_number, line)
        elif line == "::cross":
            self._parse_cross(line_number)
        else:
            self._parse_construct(line_number, line)

    def _parse_domain(self, line_number: int, line: str) -> None:
        if self.seen_header:
            self.error(line_number, "BC010", "@domain may appear only once")
            return
        if line_number != 1:
            self.error(line_number, "BC011", "@domain must be the first line")
        self.seen_header = True
        domains = line.removeprefix("@domain:").split()
        if not domains:
            self.error(line_number, "BC012", "@domain must declare at least one node type")
        for domain in domains:
            if domain not in NODE_TYPES:
                self.error(line_number, "BC013", f"unknown node type {domain!r}")
            elif domain in self.document.domains:
                self.error(line_number, "BC014", f"duplicate node type {domain!r}")
            else:
                self.document.domains.append(domain)

    def _parse_context(self, line_number: int, line: str) -> None:
        if not self.seen_header:
            self.error(line_number, "BC020", "context must follow @domain")
        if self.seen_fates or self.seen_open_ends or self.seen_pathway:
            self.error(line_number, "BC021", "context must appear before ::fates")
        if self.seen_context:
            self.error(line_number, "BC022", "context may appear only once")
        self.seen_context = True
        self.document.context = [token.removeprefix("#") for token in line.split()]

    def _parse_fates(self, line_number: int, line: str) -> None:
        if not self.seen_header:
            self.error(line_number, "BC030", "::fates must follow @domain")
        if self.seen_fates:
            self.error(line_number, "BC031", "::fates may appear only once")
        if self.seen_open_ends or self.seen_pathway:
            self.error(line_number, "BC032", "::fates must precede ::open_ends and pathways")
        self.seen_fates = True
        tokens = line.removeprefix("::fates").split()
        if not tokens:
            self.error(line_number, "BC033", "::fates must declare allowed terminal fates")
        for token in tokens:
            normalized = token[:2] if token.startswith("↺") else token[:2]
            if not any(token.startswith(fate) for fate in FATES):
                self.error(line_number, "BC034", f"unknown fate {token!r}")
            else:
                self.document.fates.append(token)

    def _parse_open_ends(self, line_number: int, line: str) -> None:
        if not self.seen_fates:
            self.error(line_number, "BC040", "::open_ends must follow ::fates")
        if self.seen_open_ends:
            self.error(line_number, "BC041", "::open_ends may appear only once")
        if self.seen_pathway:
            self.error(line_number, "BC042", "::open_ends must precede pathways")
        self.seen_open_ends = True
        match = re.fullmatch(r"::open_ends\s+(\d+)", line)
        if not match:
            self.error(line_number, "BC043", "expected ::open_ends 0")
            return
        self.document.open_ends = int(match.group(1))
        if self.document.open_ends != 0:
            self.error(line_number, "BC044", "BioChain graphs must declare ::open_ends 0")

    def _parse_delta(self, line_number: int, line: str) -> None:
        if not self.seen_open_ends:
            self.error(line_number, "BC050", "Δ declarations must follow ::open_ends 0")
        if self.seen_pathway or self.in_cross:
            self.error(line_number, "BC051", "Δ declarations must precede all pathways")
        match = re.fullmatch(
            r"Δ\(([^@()]+)@([A-Za-z0-9_]+)\)=(\+\+|--|\+|=|~|-)(?:\(exogenous:([^()]+)\))?",
            line,
        )
        if not match:
            self.error(line_number, "BC052", "invalid Δ declaration")
            return
        code, region, sign, exogenous = match.groups()
        if region not in REGIONS:
            self.error(line_number, "BC053", f"unknown region {region!r}")
        if sign not in DELTA_STATES:
            self.error(line_number, "BC054", f"invalid Δ state {sign!r}")
        delta = Delta(code, region, sign, exogenous, line_number)
        if any(existing.bare_key == delta.bare_key for existing in self.document.deltas):
            self.error(line_number, "BC055", f"duplicate Δ target {delta.bare_key}")
        self.document.deltas.append(delta)

    def _parse_pathway(self, line_number: int, line: str) -> None:
        if not self.seen_open_ends:
            self.error(line_number, "BC060", "pathways must follow ::open_ends 0")
        if self.in_cross:
            self.error(line_number, "BC061", "::cross must be the final section")
        match = re.fullmatch(r"::pathway\s+([A-Za-z0-9_.-]+)", line)
        if not match:
            self.error(line_number, "BC062", "invalid pathway name")
            return
        name = match.group(1)
        if any(pathway.name == name for pathway in self.document.pathways):
            self.error(line_number, "BC063", f"duplicate pathway {name!r}")
        self.current_pathway = Pathway(name=name, line=line_number)
        self.document.pathways.append(self.current_pathway)
        self.seen_pathway = True

    def _parse_refs(self, line_number: int, line: str) -> None:
        if self.current_pathway is None or self.in_cross:
            self.error(line_number, "BC070", "::refs must occur inside a pathway")
            return
        if self.current_pathway.constructs:
            self.error(line_number, "BC071", "::refs must precede pathway constructs")
        if self.current_pathway.refs:
            self.error(line_number, "BC072", "::refs may appear only once per pathway")
        payload = line.removeprefix("::refs").strip()
        if payload == "—":
            return
        nodes = self._extract_nodes(line_number, payload, require_ref=True)
        if not nodes:
            self.error(line_number, "BC073", "::refs requires node references or —")
        for node in nodes:
            if node.state is not None or node.props:
                self.error(line_number, "BC074", "::refs accepts node_ref values without state or props")
            if node.typed_key not in self.known_typed:
                self.error(line_number, "BC075", f"reference {node.typed_key} has not been declared upstream")
        self.current_pathway.refs.extend(nodes)

    def _parse_cross(self, line_number: int) -> None:
        if not self.seen_pathway:
            self.error(line_number, "BC080", "::cross requires at least one pathway")
        if self.in_cross:
            self.error(line_number, "BC081", "::cross may appear only once")
        self.in_cross = True
        self.current_pathway = None

    def _parse_construct(self, line_number: int, line: str) -> None:
        if not self.seen_pathway:
            self.error(line_number, "BC090", "construct appears before any pathway")
            return
        kind = self._classify_construct(line)
        if kind is None:
            self.error(line_number, "BC091", "unrecognized construct")
            return
        if self.in_cross and kind != "conditional":
            self.error(line_number, "BC092", "::cross accepts only ⊗ conditionals")
        construct = Construct(kind=kind, line=line_number, raw=line)
        if kind == "chain":
            self._parse_chain(construct)
        elif kind == "integration":
            self._parse_integration(construct)
        elif kind == "protocol":
            self._parse_protocol(construct)
        elif kind == "composite":
            self._parse_composite(construct)
        elif kind == "dysregulation":
            self._parse_dysregulation(construct)
        elif kind == "observable":
            self._parse_observable(construct)
        elif kind == "conditional":
            self._parse_conditional(construct)

        target = self.document.cross if self.in_cross else self.current_pathway.constructs
        if not self.in_cross and self.current_pathway is not None and self.current_pathway.constructs:
            previous = self.current_pathway.constructs[-1]
            if CONSTRUCT_ORDER[kind] < CONSTRUCT_ORDER[previous.kind]:
                self.error(line_number, "BC093", f"{kind} appears after {previous.kind}, violating construct order")
        target.append(construct)

    @staticmethod
    def _classify_construct(line: str) -> str | None:
        if line.startswith("∫"):
            return "integration"
        if line.startswith("◈"):
            return "composite"
        if line.startswith("⚡"):
            return "dysregulation"
        if line.startswith("⊕"):
            return "observable"
        if line.startswith("⊗"):
            return "conditional"
        if "⊲" in line:
            return "protocol"
        if "{" in line:
            return "chain"
        return None

    def _parse_node(self, line_number: int, content: str, column: int) -> Node | None:
        if ":" not in content:
            return None
        if "@" not in content:
            self.error(line_number, "BC100", "every node must end with @REGION", column)
            return None
        left, region = content.rsplit("@", 1)
        if not region or region not in REGIONS:
            self.error(line_number, "BC101", f"unknown or missing region {region!r}", column)
        node_type, sep, remainder = left.partition(":")
        if not sep or not node_type or not remainder:
            self.error(line_number, "BC102", "node must use TYPE:CODE@REGION", column)
            return None
        state: str | None = None
        props: tuple[str, ...] = ()
        code_end = len(remainder)
        indices = [index for index in (remainder.find("["), remainder.find("(")) if index >= 0]
        if indices:
            code_end = min(indices)
        code = remainder[:code_end]
        suffix = remainder[code_end:]
        if not code:
            self.error(line_number, "BC103", "node code may not be empty", column)
        if suffix.startswith("["):
            close = suffix.find("]")
            if close < 0:
                self.error(line_number, "BC104", "unterminated node state", column)
                return None
            state = suffix[1:close]
            suffix = suffix[close + 1:]
            if state not in STATES:
                self.error(line_number, "BC105", f"invalid node state {state!r}", column)
        if suffix.startswith("("):
            if not suffix.endswith(")"):
                self.error(line_number, "BC106", "unterminated node properties", column)
                return None
            raw_props = suffix[1:-1]
            props = tuple(item.strip() for item in raw_props.split(",") if item.strip())
            suffix = ""
            for prop in props:
                if prop not in NODE_PROPS:
                    self.error(line_number, "BC107", f"invalid node property {prop!r}", column)
        if suffix:
            self.error(line_number, "BC108", f"unexpected node suffix {suffix!r}", column)
        if node_type not in NODE_TYPES:
            self.error(line_number, "BC109", f"unknown node type {node_type!r}", column)
        elif self.document.domains and node_type not in self.document.domains:
            self.error(line_number, "BC110", f"node type {node_type!r} was not declared in @domain", column)
        return Node(node_type, code, region, state, props)

    def _extract_nodes(self, line_number: int, line: str, *, require_ref: bool = False) -> list[Node]:
        nodes: list[Node] = []
        for match in re.finditer(r"\{([^{}]+)\}", line):
            content = match.group(1)
            node = self._parse_node(line_number, content, match.start() + 1)
            if node is not None:
                nodes.append(node)
            elif require_ref or ":" in content:
                continue
        return nodes

    def _register_nodes(self, nodes: Iterable[Node], line_number: int) -> None:
        for node in nodes:
            self.known_typed.setdefault(node.typed_key, line_number)
            self.known_bare.setdefault(node.bare_key, line_number)

    def _parse_chain(self, construct: Construct) -> None:
        line = construct.raw
        tag: str | None = None
        match = re.match(r"^([A-Z][A-Za-z0-9_.]*):\s+", line)
        if match:
            tag = match.group(1)
            if tag not in CASCADE_TAGS:
                self.error(construct.line, "BC120", f"unknown cascade tag {tag!r}")
        construct.data["cascade"] = tag
        construct.data["root"] = "⊙" in line
        construct.nodes = self._extract_nodes(construct.line, line)
        if not construct.nodes:
            self.error(construct.line, "BC121", "chain must contain at least one valid node")
            return
        terminal = self._terminal(line)
        if terminal is None:
            self.error(construct.line, "BC122", "chain has no explicit fate or loop closure")
        else:
            construct.data["terminal"] = terminal
        if "⊙" in line:
            root = construct.nodes[0].bare_key
            delta = next((item for item in self.document.deltas if item.bare_key == root), None)
            if delta is None:
                self.error(construct.line, "BC123", f"root {root} has no Δ declaration")
            elif delta.sign == "=":
                self.error(construct.line, "BC124", f"root {root} must have Δ≠0")
        self._validate_cascade(construct, tag)
        if any(node.type == "T" and node.code == "SERT" and node.region == "DRN" for node in construct.nodes):
            self.error(construct.line, "BC125", "SERT@DRN violates target-tissue placement; use a projection target")
        self._register_nodes(construct.nodes, construct.line)

    @staticmethod
    def _terminal(line: str) -> str | None:
        patterns = (
            r"↺[⁺⁻⁰](?:\([^)]*\))?$",
            r"→⊘$",
            r"→□\([^)]*\)$",
            r"→≋$",
            r"→Δm\([^)]*\)$",
            r"=>\[cb\]→[^\s]+=(?:\+\+|--|\+|=|~|-)→\{[^{}]+\}(?:↺[⁺⁻⁰](?:\([^)]*\))?)?$",
        )
        for pattern in patterns:
            match = re.search(pattern, line)
            if match:
                return match.group(0)
        return None

    def _validate_cascade(self, construct: Construct, tag: str | None) -> None:
        if tag is None:
            return
        nodes = construct.nodes
        types = [node.type for node in nodes]

        def ordered(required: list[str]) -> bool:
            cursor = 0
            for node_type in types:
                if cursor < len(required) and node_type == required[cursor]:
                    cursor += 1
            return cursor == len(required)

        if tag.startswith("GPCR."):
            coupling = tag.split(".", 1)[1]
            if not ordered(["L.nt" if nodes[0].type == "L.nt" else nodes[0].type, "R", "Gp", "2m", "K"]):
                self.error(construct.line, "BC130", f"{tag} requires L→R→Gp→2m→K")
            receptor = next((node for node in nodes if node.type == "R"), None)
            gp = next((node for node in nodes if node.type == "Gp"), None)
            messengers = [node for node in nodes if node.type == "2m"]
            if receptor is None or coupling not in receptor.props:
                self.error(construct.line, "BC131", f"{tag} receptor must carry ({coupling})")
            if gp is None or gp.code != coupling:
                self.error(construct.line, "BC132", f"{tag} requires {{Gp:{coupling}@REGION}}")
            if coupling in {"Gs", "Gi"} and any(node.code != "cAMP" for node in messengers):
                self.error(construct.line, "BC133", f"{tag} second messenger must be cAMP")
            if coupling == "Gq" and any(node.code not in {"IP3", "DAG"} for node in messengers):
                self.error(construct.line, "BC134", "GPCR.Gq second messengers must be IP3 or DAG")
        elif tag == "NUCLEAR" and not ordered(["L.h", "NR", "TF", "G"]):
            self.error(construct.line, "BC135", "NUCLEAR requires L.h→NR→TF→G")
        elif tag == "RTK":
            if not ordered([nodes[0].type, "R", "K", "TF"]):
                self.error(construct.line, "BC136", "RTK requires L→R→K→TF")
            receptor = next((node for node in nodes if node.type == "R"), None)
            if receptor is None or "RTK" not in receptor.props:
                self.error(construct.line, "BC137", "RTK receptor must carry (RTK)")
        elif tag == "CYTOKINE":
            if not ordered([nodes[0].type, "R", "K", "TF"]):
                self.error(construct.line, "BC138", "CYTOKINE requires L→R→K→TF")
            receptor = next((node for node in nodes if node.type == "R"), None)
            if receptor is None or "JAK-STAT" not in receptor.props:
                self.error(construct.line, "BC139", "CYTOKINE receptor must carry (JAK-STAT)")
        elif tag == "IONOTROPIC":
            receptor = next((node for node in nodes if node.type == "R"), None)
            if receptor is None or not set(receptor.props).intersection({"Cl⁻", "Ca²⁺", "Na⁺", "K⁺"}):
                self.error(construct.line, "BC140", "IONOTROPIC receptor requires an ion property")
            if not ordered(["R", "2m"]):
                self.error(construct.line, "BC141", "IONOTROPIC requires R→2m")
        elif tag == "VAGAL":
            expected = [("N.ent", "ENS"), ("E.v", "VAG")]
            for node_type, region in expected:
                if not any(node.type == node_type and node.region == region for node in nodes):
                    self.error(construct.line, "BC142", f"VAGAL requires {node_type}@{region}")
            if not any(node.type.startswith("N.") and node.region == "NTS" for node in nodes):
                self.error(construct.line, "BC143", "VAGAL requires a neural target at NTS")
        elif tag == "GUT_HORMONE":
            required = [("N.eec", "ENS"), ("L.h", "GUT")]
            for node_type, region in required:
                if not any(node.type == node_type and node.region == region for node in nodes):
                    self.error(construct.line, "BC144", f"GUT_HORMONE requires {node_type}@{region}")
            if not any(node.type == "R" and node.region in {"ARC", "NTS", "AP"} for node in nodes):
                self.error(construct.line, "BC145", "GUT_HORMONE receptor must target ARC, NTS, or AP")

    def _parse_integration(self, construct: Construct) -> None:
        match = re.fullmatch(r"∫\{([^{}]+)\}←\(([^()]*)\)→\{([^{}]+)\}:(thr|rate|burst|tonic)", construct.raw)
        if not match:
            self.error(construct.line, "BC150", "invalid ∫ integration")
            return
        unit_raw, inputs_raw, output_raw, mode = match.groups()
        unit = self._parse_typed_ref(construct.line, unit_raw)
        output = self._parse_typed_ref(construct.line, output_raw)
        inputs: list[dict[str, str]] = []
        for raw_input in self._split_csv(inputs_raw):
            input_match = re.fullmatch(r"([^@,]+)@([A-Za-z0-9_]+):([+\-×])", raw_input)
            if not input_match:
                self.error(construct.line, "BC151", f"invalid ∫ input {raw_input!r}")
                continue
            code, region, sign = input_match.groups()
            bare = f"{code}@{region}"
            inputs.append({"code": code, "region": region, "sign": sign})
            if bare not in self.known_bare:
                self.error(construct.line, "BC152", f"∫ input {bare} was not declared in an earlier chain")
            if code == "ATP" and sign != "×":
                self.error(construct.line, "BC153", "ATP availability must use ×")
        if unit and output and unit[1] == output[1]:
            self.error(construct.line, "BC154", "∫ unit and output must differ")
        for role, ref in (("unit", unit), ("output", output)):
            if ref and ref[1] not in self.known_bare:
                self.error(construct.line, "BC155", f"∫ {role} {ref[1]} was not declared in an earlier chain")
        construct.data.update({"unit": unit_raw, "inputs": inputs, "output": output_raw, "mode": mode})

    def _parse_typed_ref(self, line_number: int, raw: str) -> tuple[str | None, str] | None:
        match = re.fullmatch(r"(?:(\S+):)?([^@]+)@([A-Za-z0-9_]+)", raw)
        if not match:
            self.error(line_number, "BC156", f"invalid typed_ref {raw!r}")
            return None
        node_type, code, region = match.groups()
        if node_type and node_type not in NODE_TYPES:
            self.error(line_number, "BC157", f"unknown typed_ref type {node_type!r}")
        if region not in REGIONS:
            self.error(line_number, "BC158", f"unknown typed_ref region {region!r}")
        return node_type, f"{code}@{region}"

    def _parse_protocol(self, construct: Construct) -> None:
        match = re.fullmatch(r"(\{[^{}]+\})⊲(\{[^{}]+\})\[([^\]]+)\]", construct.raw)
        if not match:
            self.error(construct.line, "BC160", "invalid ⊲ protocol")
            return
        source_raw, target_raw, params_raw = match.groups()
        construct.nodes = self._extract_nodes(construct.line, source_raw + target_raw, require_ref=True)
        params = params_raw.split()
        for param in params:
            if param not in PROTOCOL_PARAMS and not re.fullmatch(r"[^\s]+(?:>=)(?:\+\+|--|\+|=|~|-|X|\*)", param):
                self.error(construct.line, "BC161", f"invalid protocol parameter {param!r}")
        for node in construct.nodes:
            if node.typed_key not in self.known_typed:
                self.error(construct.line, "BC162", f"protocol node {node.typed_key} was not declared earlier")
        construct.data["params"] = params

    def _parse_composite(self, construct: Construct) -> None:
        match = re.fullmatch(r"◈([A-Za-z0-9_.-]+)=(\{[^{}]+\}(?:\+\{[^{}]+\})*)", construct.raw)
        if not match:
            self.error(construct.line, "BC170", "invalid ◈ composite")
            return
        construct.data["name"] = match.group(1)
        construct.nodes = self._extract_nodes(construct.line, match.group(2), require_ref=True)
        for node in construct.nodes:
            if node.typed_key not in self.known_typed:
                self.error(construct.line, "BC171", f"composite node {node.typed_key} was not declared earlier")

    def _parse_dysregulation(self, construct: Construct) -> None:
        match = re.fullmatch(r"⚡([A-Za-z0-9_.-]+):(.+)\(([A-Za-z0-9_.-]+)\)", construct.raw)
        if not match:
            self.error(construct.line, "BC180", "invalid ⚡ dysregulation")
            return
        flag, chain_raw, dynamics = match.groups()
        construct.data.update({"flag": flag, "chain": chain_raw, "dynamics": dynamics})
        construct.nodes = self._extract_nodes(construct.line, chain_raw)

    def _parse_observable(self, construct: Construct) -> None:
        match = re.fullmatch(r"⊕([A-Za-z0-9_.-]+)→(.+)\((direct|proxy|ratio|activity|metabolite|autonomic)\)", construct.raw)
        if not match:
            self.error(construct.line, "BC190", "invalid ⊕ observable")
            return
        measurement, node_raw, relationship = match.groups()
        construct.nodes = self._extract_nodes(construct.line, node_raw, require_ref=True)
        if not construct.nodes:
            self.error(construct.line, "BC191", "observable requires at least one node")
        for node in construct.nodes:
            if node.typed_key not in self.known_typed:
                self.error(construct.line, "BC192", f"observable node {node.typed_key} was not declared earlier")
        construct.data.update({"measurement": measurement, "relationship": relationship})

    def _parse_conditional(self, construct: Construct) -> None:
        match = re.fullmatch(r"⊗\((.+)\)⟹(\{[^{}]+\}):(pass|block|amplify|switch:[A-Za-z0-9_.-]+|apoptosis)", construct.raw)
        if not match:
            self.error(construct.line, "BC200", "invalid ⊗ conditional")
            return
        conditions_raw, effect_raw, action = match.groups()
        construct.nodes = self._extract_nodes(construct.line, conditions_raw + effect_raw, require_ref=True)
        condition_parts = re.split(r"[∧∨]", conditions_raw)
        for condition in condition_parts:
            if not re.fullmatch(r"¬?\{[^{}]+\}>=(?:\+\+|--|\+|=|~|-|X|\*)", condition):
                self.error(construct.line, "BC201", f"invalid condition {condition!r}")
        for node in construct.nodes:
            if node.typed_key not in self.known_typed:
                self.error(construct.line, "BC202", f"conditional node {node.typed_key} was not declared earlier")
        construct.data["action"] = action

    @staticmethod
    def _split_csv(value: str) -> list[str]:
        return [item.strip() for item in value.split(",") if item.strip()]

    def _finish(self, lines: list[str]) -> None:
        final_line = max(1, len(lines))
        if not self.seen_header:
            self.error(1, "BC300", "missing @domain header")
        if not self.seen_fates:
            self.error(final_line, "BC301", "missing ::fates declaration")
        if not self.seen_open_ends:
            self.error(final_line, "BC302", "missing ::open_ends 0")
        if not self.document.pathways:
            self.error(final_line, "BC303", "at least one ::pathway is required")
        for pathway in self.document.pathways:
            if not pathway.constructs:
                self.error(pathway.line, "BC304", f"pathway {pathway.name!r} is empty")
        if self.clinical and len(self.document.pathways) < 4:
            self.error(final_line, "BC305", "clinical mode requires at least four pathways")
        if self.clinical:
            for pathway in self.document.pathways:
                if not any(construct.kind == "observable" for construct in pathway.constructs):
                    self.error(
                        pathway.line,
                        "BC306",
                        f"clinical mode requires an observable in pathway {pathway.name!r}",
                    )


def compile_source(source: str, *, clinical: bool = False) -> CompilationResult:
    """Compile BioChain-BASE source into validated JSON-ready IR."""
    return Compiler(clinical=clinical).compile(source)
