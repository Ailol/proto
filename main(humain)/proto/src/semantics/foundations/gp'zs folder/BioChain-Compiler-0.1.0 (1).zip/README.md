# BioChain Compiler

`biochain` compiles BioChain-BASE formulas into deterministic JSON IR.

It fails closed on malformed syntax, missing regions, dead-end chains, undeclared roots, cascade/coupling mismatches, invalid construct order, unresolved references, and forbidden operators.

## Run

No runtime dependencies are required beyond Python 3.11+.

```bash
cd biochain-compiler
PYTHONPATH=src python -m biochain_compiler check examples/valid.bio --clinical
PYTHONPATH=src python -m biochain_compiler compile examples/valid.bio --clinical -o example.bc.json
PYTHONPATH=src python -m biochain_compiler check examples/full.bio
```

The compiler exits `0` only when the source is valid; invalid source exits `1` and produces no IR.

`--clinical` is a structural doctor-gate: it requires at least four pathways and at least one measurable observable per pathway.

## Install the command

```bash
python -m pip install -e .
biochain check examples/valid.bio --clinical
biochain compile examples/valid.bio --clinical
```

## Test

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Output contract

The JSON IR preserves domains, context, perturbations, pathways, node types, regions, source lines, constructs, cascade tags, terminal fates, and the original canonical formula line.

The compiler validates topology and declared semantics; it does not claim that an emitted biological pathway is clinically true.

Every emitted IR is provisional, disables automatic ingrainment, and states that doctor review is required.

Healthy BioChain ingrainment is intentionally slow: compile fast, observe repeatedly, challenge the generator, review clinically, then decide what deserves to persist.

Credit: Ailo and GP.
