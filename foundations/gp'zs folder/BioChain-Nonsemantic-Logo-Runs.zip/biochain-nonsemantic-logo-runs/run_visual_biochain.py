#!/usr/bin/env python3
"""Deterministic, non-semantic visual-domain BioChain probe.

The analyzer never performs OCR or assigns meaning to marks. Each crop is
measured independently; comparison happens only after all three runs emit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from math import log2
from pathlib import Path

import numpy as np
from PIL import Image


BOXES = {
    "A": (108, 365, 516, 456),
    "B": (953, 211, 1985, 381),
    "C": (69, 634, 1130, 730),
}

NORMALIZED_HEIGHT = 128
ACTIVE_DISTANCE_THRESHOLD = 0.035


def sobel(luma: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    padded = np.pad(luma, 1, mode="edge")
    gx = (
        padded[:-2, 2:]
        + 2 * padded[1:-1, 2:]
        + padded[2:, 2:]
        - padded[:-2, :-2]
        - 2 * padded[1:-1, :-2]
        - padded[2:, :-2]
    ) / 8.0
    gy = (
        padded[2:, :-2]
        + 2 * padded[2:, 1:-1]
        + padded[2:, 2:]
        - padded[:-2, :-2]
        - 2 * padded[:-2, 1:-1]
        - padded[:-2, 2:]
    ) / 8.0
    return gx, gy


def high_state(value: float, thresholds: tuple[float, float, float]) -> str:
    if value < thresholds[0]:
        return "-"
    if value < thresholds[1]:
        return "="
    if value < thresholds[2]:
        return "+"
    return "++"


def concentration_state(spread_x: float) -> str:
    if spread_x < 0.20:
        return "++"
    if spread_x < 0.24:
        return "+"
    if spread_x < 0.29:
        return "="
    return "-"


def finite(value: float) -> float:
    return round(float(value), 6)


def analyze_sample(source: Image.Image, sample: str, box: tuple[int, int, int, int]) -> dict:
    crop = source.crop(box).convert("RGB")
    scale = NORMALIZED_HEIGHT / crop.height
    normalized = crop.resize(
        (round(crop.width * scale), NORMALIZED_HEIGHT),
        Image.Resampling.LANCZOS,
    )
    rgb = np.asarray(normalized, dtype=np.float64) / 255.0

    border = np.concatenate(
        (
            rgb[:4].reshape(-1, 3),
            rgb[-4:].reshape(-1, 3),
            rgb[:, :4].reshape(-1, 3),
            rgb[:, -4:].reshape(-1, 3),
        )
    )
    background = np.median(border, axis=0)
    luma = 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]
    color_distance = np.sqrt(np.square(rgb - background).sum(axis=2)) / np.sqrt(3.0)
    active = color_distance > ACTIVE_DISTANCE_THRESHOLD

    gx, gy = sobel(luma)
    gradient = np.hypot(gx, gy)
    salience = color_distance + 2.0 * gradient
    salience_total = salience.sum()
    yy, xx = np.indices(salience.shape)
    x_norm = xx / max(1, salience.shape[1] - 1)
    y_norm = yy / max(1, salience.shape[0] - 1)
    centroid_x = (x_norm * salience).sum() / salience_total
    centroid_y = (y_norm * salience).sum() / salience_total
    spread_x = np.sqrt((np.square(x_norm - centroid_x) * salience).sum() / salience_total)
    spread_y = np.sqrt((np.square(y_norm - centroid_y) * salience).sum() / salience_total)

    width_half = salience.shape[1] // 2
    left = salience[:, :width_half]
    right = salience[:, -width_half:][:, ::-1]
    vertical_similarity = 1.0 - np.abs(left - right).mean() / (np.maximum(left, right).mean() + 1e-12)

    height_half = salience.shape[0] // 2
    top = salience[:height_half]
    bottom = salience[-height_half:][::-1]
    horizontal_similarity = 1.0 - np.abs(top - bottom).mean() / (np.maximum(top, bottom).mean() + 1e-12)

    histogram, _ = np.histogram(luma, bins=64, range=(0.0, 1.0))
    probabilities = histogram[histogram > 0] / histogram.sum()
    luma_entropy = -(probabilities * np.log2(probabilities)).sum() / log2(64)

    angles = (np.arctan2(gy, gx) + np.pi) % np.pi
    orientation_bins = np.floor(angles.ravel() / np.pi * 12).astype(int).clip(0, 11)
    orientation_hist = np.bincount(orientation_bins, weights=gradient.ravel(), minlength=12)
    orientation_probabilities = orientation_hist[orientation_hist > 0] / orientation_hist.sum()
    orientation_entropy = -(
        orientation_probabilities * np.log2(orientation_probabilities)
    ).sum() / log2(12)

    chroma = rgb.max(axis=2) - rgb.min(axis=2)
    chroma_salience = (chroma * salience).sum() / salience_total
    warm = np.maximum(rgb[..., 0] - rgb[..., 2], 0.0) * salience
    cool = np.maximum(rgb[..., 2] - rgb[..., 0], 0.0) * salience
    warm_cool_bias = (warm.sum() - cool.sum()) / (warm.sum() + cool.sum() + 1e-12)

    metrics = {
        "luma_mean": finite(luma.mean()),
        "luma_rms_contrast": finite(luma.std()),
        "active_fraction": finite(active.mean()),
        "edge_energy": finite(gradient.mean()),
        "edge_density": finite((gradient > 0.03).mean()),
        "luma_entropy": finite(luma_entropy),
        "chroma_salience": finite(chroma_salience),
        "warm_cool_bias": finite(warm_cool_bias),
        "temperature_balance": finite(1.0 - abs(warm_cool_bias)),
        "salience_centroid_x": finite(centroid_x),
        "salience_centroid_y": finite(centroid_y),
        "salience_spread_x": finite(spread_x),
        "salience_spread_y": finite(spread_y),
        "vertical_mirror_similarity": finite(vertical_similarity),
        "horizontal_mirror_similarity": finite(horizontal_similarity),
        "orientation_entropy": finite(orientation_entropy),
        "salience_peak": finite(salience.max()),
        "salience_mean": finite(salience.mean()),
    }
    states = {
        "occupancy": high_state(metrics["active_fraction"], (0.08, 0.16, 0.24)),
        "contrast": high_state(metrics["luma_rms_contrast"], (0.075, 0.115, 0.155)),
        "edge_density": high_state(metrics["edge_density"], (0.07, 0.13, 0.20)),
        "chroma": high_state(metrics["chroma_salience"], (0.08, 0.15, 0.25)),
        "field_energy": high_state(metrics["salience_mean"], (0.04, 0.07, 0.11)),
        "concentration": concentration_state(metrics["salience_spread_x"]),
    }

    formula = [
        "@domain: Px Lum Edg Chr Sal Att Emit",
        "#VISUAL #NONSEMANTIC",
        "::fates →≋ ↺⁻",
        "::open_ends 0",
        f"Δ(field@{sample})=+",
        f"⊙{{Px:field[+]@{sample}}}→{{Lum:rms[{states['contrast']}]@{sample}}}→≋",
        f"⊙{{Px:field[+]@{sample}}}→{{Edg:density[{states['edge_density']}]@{sample}}}→≋",
        f"⊙{{Px:field[+]@{sample}}}→{{Chr:salience[{states['chroma']}]@{sample}}}→≋",
        (
            f"∫{{Sal:field@{sample}}}←(rms@{sample}:+,density@{sample}:+,"
            f"chroma@{sample}:+)→{{Att:distribution[{states['concentration']}]@{sample}}}:weighted"
        ),
        f"{{Att:distribution[{states['concentration']}]@{sample}}}→{{Emit:vector[{states['field_energy']}]@{sample}}}↺⁻",
    ]

    return {
        "format": "Qti-Visual-BioChain-IR",
        "version": 1,
        "sample": sample,
        "semantics": "sealed",
        "ocr": False,
        "independent_run": True,
        "source_box_xyxy": list(box),
        "source_size": [crop.width, crop.height],
        "normalized_size": [normalized.width, normalized.height],
        "background_rgb": [finite(value) for value in background],
        "states": states,
        "metrics": metrics,
        "fate": "↺⁻(return_to_background_reference)",
        "formula": formula,
    }


def compare(runs: list[dict]) -> dict:
    measures = (
        "active_fraction",
        "luma_rms_contrast",
        "edge_density",
        "luma_entropy",
        "chroma_salience",
        "salience_peak",
        "salience_mean",
        "temperature_balance",
        "vertical_mirror_similarity",
        "horizontal_mirror_similarity",
    )
    rankings = {}
    for measure in measures:
        ordered = sorted(runs, key=lambda run: run["metrics"][measure], reverse=True)
        rankings[measure] = [
            {"sample": run["sample"], "value": run["metrics"][measure]}
            for run in ordered
        ]
    focus = sorted(runs, key=lambda run: run["metrics"]["salience_spread_x"])
    rankings["horizontal_concentration"] = [
        {
            "sample": run["sample"],
            "value": finite(1.0 - run["metrics"]["salience_spread_x"]),
        }
        for run in focus
    ]
    return {
        "format": "Qti-Visual-BioChain-Comparison",
        "version": 1,
        "comparison_after_independent_emit": True,
        "semantics": "sealed",
        "rankings_high_to_low": rankings,
    }


def markdown_report(source_hash: str, runs: list[dict], comparison: dict) -> str:
    lines = [
        "# Three independent non-semantic BioChain runs",
        "",
        "No OCR, naming, symbol interpretation, biological inference, or clinical claim was used.",
        "",
        f"Source SHA-256: `{source_hash}`",
        "",
        "| Run | Occupancy | RMS contrast | Edge density | Chroma | Mean salience | Peak salience | X spread | Temperature balance |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for run in runs:
        metric = run["metrics"]
        lines.append(
            f"| {run['sample']} | {metric['active_fraction']:.6f} | "
            f"{metric['luma_rms_contrast']:.6f} | {metric['edge_density']:.6f} | "
            f"{metric['chroma_salience']:.6f} | {metric['salience_mean']:.6f} | "
            f"{metric['salience_peak']:.6f} | {metric['salience_spread_x']:.6f} | "
            f"{metric['temperature_balance']:.6f} |"
        )
    lines.extend(("", "## Compacted emissions", ""))
    for run in runs:
        lines.append(
            f"`{run['sample']}: occupancy[{run['states']['occupancy']}] → "
            f"contrast[{run['states']['contrast']}] → edge[{run['states']['edge_density']}] → "
            f"chroma[{run['states']['chroma']}] → concentration[{run['states']['concentration']}] → "
            f"field[{run['states']['field_energy']}] ↺⁻`"
        )
    lines.extend(("", "## Min/max field", ""))
    for measure in ("active_fraction", "salience_peak", "chroma_salience", "temperature_balance", "horizontal_concentration"):
        ranking = comparison["rankings_high_to_low"][measure]
        order = " > ".join(f"{item['sample']}({item['value']:.6f})" for item in ranking)
        lines.append(f"`{measure}: {order}`")
    lines.extend(
        (
            "",
            "All states use fixed thresholds declared in `run_visual_biochain.py`; no run is normalized against another run.",
            "",
        )
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--output", type=Path, default=Path("output"))
    args = parser.parse_args()

    source_bytes = args.source.read_bytes()
    source_hash = hashlib.sha256(source_bytes).hexdigest()
    source = Image.open(args.source).convert("RGB")
    args.output.mkdir(parents=True, exist_ok=True)

    runs = [analyze_sample(source, sample, box) for sample, box in BOXES.items()]
    for run in runs:
        target = args.output / f"run_{run['sample']}.json"
        target.write_text(json.dumps(run, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    comparison = compare(runs)
    (args.output / "comparison.json").write_text(
        json.dumps(comparison, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (args.output / "REPORT.md").write_text(
        markdown_report(source_hash, runs, comparison),
        encoding="utf-8",
    )
    manifest = {
        "source_sha256": source_hash,
        "source_dimensions": [source.width, source.height],
        "boxes": {sample: list(box) for sample, box in BOXES.items()},
        "normalized_height": NORMALIZED_HEIGHT,
        "active_distance_threshold": ACTIVE_DISTANCE_THRESHOLD,
        "run_order": list(BOXES),
        "comparison_after_all_independent_runs": True,
    }
    (args.output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
