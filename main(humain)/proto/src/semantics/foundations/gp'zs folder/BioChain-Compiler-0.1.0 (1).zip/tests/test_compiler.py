from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from biochain_compiler import compile_source


ROOT = Path(__file__).resolve().parents[1]


class CompilerTests(unittest.TestCase):
    def test_valid_fixture_compiles_in_clinical_mode(self) -> None:
        source = (ROOT / "examples" / "valid.bio").read_text(encoding="utf-8")
        result = compile_source(source, clinical=True)
        self.assertTrue(result.ok, "\n".join(item.render() for item in result.diagnostics))
        ir = json.loads(result.ir_json())
        self.assertEqual(ir["format"], "BioChain-BASE-IR")
        self.assertEqual(len(ir["pathways"]), 4)
        self.assertEqual(ir["profile"], "clinical-structure")
        self.assertFalse(ir["ingrainment"]["automatic"])
        self.assertTrue(ir["ingrainment"]["doctor_review_required"])

    def test_invalid_fixture_fails_closed(self) -> None:
        source = (ROOT / "examples" / "invalid.bio").read_text(encoding="utf-8")
        result = compile_source(source)
        codes = {item.code for item in result.diagnostics if item.severity == "error"}
        self.assertFalse(result.ok)
        self.assertIn("BC122", codes)
        self.assertIn("BC131", codes)
        self.assertIn("BC132", codes)

    def test_full_language_surface_compiles(self) -> None:
        source = (ROOT / "examples" / "full.bio").read_text(encoding="utf-8")
        result = compile_source(source)
        self.assertTrue(result.ok, "\n".join(item.render() for item in result.diagnostics))
        ir = json.loads(result.ir_json())
        kinds = {
            construct["kind"]
            for pathway in ir["pathways"]
            for construct in pathway["constructs"]
        }
        self.assertTrue(
            {
                "chain",
                "integration",
                "protocol",
                "composite",
                "dysregulation",
                "observable",
                "conditional",
            }.issubset(kinds)
        )
        self.assertEqual(ir["cross"][0]["kind"], "conditional")

    def test_missing_region_is_rejected(self) -> None:
        source = "\n".join(
            [
                "@domain: L.h",
                "::fates →⊘",
                "::open_ends 0",
                "::pathway x",
                "::refs —",
                "{L.h:CRH[+]}→⊘",
            ]
        )
        result = compile_source(source)
        self.assertIn("BC100", {item.code for item in result.diagnostics})

    def test_blank_line_is_parse_failure(self) -> None:
        source = "@domain: L.h\n::fates →⊘\n::open_ends 0\n\n::pathway x\n{L.h:X[=]@PVN}→⊘\n"
        result = compile_source(source)
        self.assertIn("BC002", {item.code for item in result.diagnostics})

    def test_clinical_mode_requires_observable_per_pathway(self) -> None:
        source = "\n".join(
            [
                "@domain: L.h",
                "::fates →⊘",
                "::open_ends 0",
                "::pathway a",
                "{L.h:A[=]@PVN}→⊘",
                "::pathway b",
                "{L.h:B[=]@PVN}→⊘",
                "::pathway c",
                "{L.h:C[=]@PVN}→⊘",
                "::pathway d",
                "{L.h:D[=]@PVN}→⊘",
            ]
        )
        result = compile_source(source, clinical=True)
        self.assertIn("BC306", {item.code for item in result.diagnostics})

    def test_cli_emits_json_ir(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "compiled.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "biochain_compiler",
                    "compile",
                    str(ROOT / "examples" / "valid.bio"),
                    "--clinical",
                    "-o",
                    str(output),
                ],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(json.loads(output.read_text(encoding="utf-8"))["version"], 1)


if __name__ == "__main__":
    unittest.main()
