# Non-semantic visual BioChain probe

This probe runs three image fields independently and compares them only after each has emitted its own measurement vector.

It performs no OCR and assigns no meaning to text, symbols, brands, people, relationships, intent, health, or biology. It is a visual domain-pack experiment using BioChain's closed-path mechanics, not the clinical BioChain vocabulary.

## Run

```bash
python3 run_visual_biochain.py /path/to/source.png --output output
```

Dependencies: Python 3.11+, Pillow, NumPy.

## Output

- `run_A.json`, `run_B.json`, `run_C.json`: independent IR and compacted formula.
- `comparison.json`: ranking created only after the three independent emissions.
- `REPORT.md`: compact comparison.
- `manifest.json`: source digest, crop coordinates, and normalization contract.
- `SEMANTIC_OVERLAY.md`: optional second-pass deployment meaning; raw runs remain unchanged.
- `deployment_overlay.json`: the same role mapping in portable form.

The fixed measurements are luminance, RMS contrast, active field coverage, edge energy and density, luminance entropy, chroma salience, temperature balance, salience centroid and spread, mirror similarity, orientation entropy, and salience peak/mean.

Every run closes with `↺⁻(return_to_background_reference)`; nothing is ingrained.

The semantic overlay is downstream of measurement. It can be replaced without rerunning or mutating the non-semantic layer.
