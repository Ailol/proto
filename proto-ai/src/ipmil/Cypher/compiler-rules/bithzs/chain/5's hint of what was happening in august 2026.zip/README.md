# Universal Chain Language — Microservices

Eight grammars. Each one a chair. Sit where you need.

| File | Operator | What it does |
|------|----------|-------------|
| `node.ebnf` | `{TYPE:CODE[STATE]@REGION}` | The seat. Identity, state, location. |
| `edge.ebnf` | `→ ⊣ ~> => \|>` | The connections between seats. |
| `state.ebnf` | `++ + = ~ - -- X *` | How things feel right now. |
| `fate.ebnf` | `↺⁺ ↺⁻ ↺⁰ →⊘ →□ →≋ →Δm` | Where every chain ends. No dead ends. |
| `integration.ebnf` | `∫` | Where signals meet and one decision comes out. |
| `protocol.ebnf` | `⊲` | How signals transfer. The handshake. |
| `conditional.ebnf` | `⊗` | The AND gate. All conditions or nothing. |
| `observable.ebnf` | `⊕` | The window from inside to outside. |
| `composite.ebnf` | `◈` | When chairs form a table. |
| `dysreg.ebnf` | `⚡` | When things break. |

## How to use

Pick the microservices your domain needs. Import them. Compose your honeycomb.

A new domain doesn't need all ten. A simple chain needs `node`, `edge`, `state`, `fate`. That's four files. Four chairs. Enough to start telling stories.

A complex domain adds `integration`, `protocol`, `conditional`, `observable`. More chairs. More people in the room. The dragon still guards the door.

## The energy

This isn't 128 BPM forge work. That's in the domain grammars (`biochain_base.ebnf` etc.).

This is 108 BPM. Chairs out. Dragon at the door. Come sit. Tell your story in chains. The grammar keeps you honest. The room keeps you safe.

## Principles

1. Every node has a seat (`@REGION`)
2. Every chain ends somewhere (fate)
3. Every connection has a verb (edge)
4. Every observation bridges inside to outside (observable)
5. The graph closes (`::open_ends 0`)

## Felt in Norway
