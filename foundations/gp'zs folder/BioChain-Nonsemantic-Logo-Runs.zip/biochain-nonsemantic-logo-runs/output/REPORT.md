# Three independent non-semantic BioChain runs

No OCR, naming, symbol interpretation, biological inference, or clinical claim was used.

Source SHA-256: `617d61093f13491aba382b065620d38a1b49234d51f69da1475d715caf046959`

| Run | Occupancy | RMS contrast | Edge density | Chroma | Mean salience | Peak salience | X spread | Temperature balance |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| A | 0.201396 | 0.125066 | 0.117732 | 0.107543 | 0.089917 | 1.341681 | 0.273236 | 0.003952 |
| B | 0.116836 | 0.107808 | 0.116192 | 0.169584 | 0.060746 | 1.560674 | 0.178812 | 0.005653 |
| C | 0.061418 | 0.062060 | 0.051082 | 0.056294 | 0.031905 | 1.266610 | 0.255105 | 0.770379 |

## Compacted emissions

`A: occupancy[+] → contrast[+] → edge[=] → chroma[=] → concentration[=] → field[+] ↺⁻`
`B: occupancy[=] → contrast[=] → edge[=] → chroma[+] → concentration[++] → field[=] ↺⁻`
`C: occupancy[-] → contrast[-] → edge[-] → chroma[-] → concentration[=] → field[-] ↺⁻`

## Min/max field

`active_fraction: A(0.201396) > B(0.116836) > C(0.061418)`
`salience_peak: B(1.560674) > A(1.341681) > C(1.266610)`
`chroma_salience: B(0.169584) > A(0.107543) > C(0.056294)`
`temperature_balance: C(0.770379) > B(0.005653) > A(0.003952)`
`horizontal_concentration: B(0.821188) > C(0.744895) > A(0.726764)`

All states use fixed thresholds declared in `run_visual_biochain.py`; no run is normalized against another run.
