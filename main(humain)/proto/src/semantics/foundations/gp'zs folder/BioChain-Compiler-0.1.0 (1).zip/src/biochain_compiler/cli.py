from __future__ import annotations

import argparse
from pathlib import Path
import sys

from .compiler import compile_source


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="biochain", description="Compile BioChain-BASE source")
    subparsers = parser.add_subparsers(dest="command", required=True)

    for command in ("check", "compile"):
        subparser = subparsers.add_parser(command)
        subparser.add_argument("source", type=Path)
        subparser.add_argument("--clinical", action="store_true", help="require at least four pathways")
        if command == "compile":
            subparser.add_argument("-o", "--output", type=Path)
            subparser.add_argument("--compact", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        source = args.source.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"{args.source}: error BC000: {exc}", file=sys.stderr)
        return 2

    result = compile_source(source, clinical=args.clinical)
    for diagnostic in result.diagnostics:
        print(diagnostic.render(str(args.source)), file=sys.stderr)
    if not result.ok:
        return 1

    if args.command == "check":
        print(f"{args.source}: ok")
        return 0

    output = args.output or args.source.with_suffix(".bc.json")
    try:
        output.write_text(result.ir_json(pretty=not args.compact), encoding="utf-8")
    except OSError as exc:
        print(f"{output}: error BC000: {exc}", file=sys.stderr)
        return 2
    print(output)
    return 0

